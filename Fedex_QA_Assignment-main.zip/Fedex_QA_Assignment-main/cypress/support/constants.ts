export const staticTexts = {
  titleText: "The Star Wars Search",
  resultsNotFound: "Not found.",
  labelGender: "Gender:",
  labelBirthYear: "Birth year:",
  labelEyeColor: "Eye color:",
  labelPopulation: "Population:",
  labelClimate: "Climate:",
  labelGravity: "Gravity:",
};